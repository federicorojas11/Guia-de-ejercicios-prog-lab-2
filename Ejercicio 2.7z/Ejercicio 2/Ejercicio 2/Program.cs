﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {

            
            int numero = 0;
            int cuadrado;
            int cubo;
            string numeroString;
            bool result;
            Console.WriteLine("Ingrese un numero");
            numeroString = Console.ReadLine();

            result = int.TryParse(numeroString, out numero);

            if (result == false)
            {                
                Console.WriteLine("false");
            }
            else
            {
                cuadrado = numero;
                cuadrado = (int)Math.Pow(numero, 2);
                                                
                cubo = (int)Math.Pow(numero, 3);
                Console.WriteLine("Cuadrado: {0}\nCubo: {1}", cuadrado, cubo);
            }

            Console.ReadKey();
        }
    }
}
