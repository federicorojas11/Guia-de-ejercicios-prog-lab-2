﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre = "Fede";
            int numero;
            int acumulador = 0;
            int minimo = 0;
            int maximo = 0;
            int promedio = 0;


            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("Hola {0}!!", nombre);
            //tabulaciones de WriteLine
            //Console.WriteLine("Hola {0,10}!!", nombre);
            //Console.WriteLine("Hola {0,-10}!!", nombre);

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingresa un numero");
                numero = Convert.ToInt32(Console.ReadLine());

                if (i == 0 || minimo > numero)
                {
                    minimo = numero;
                }

                if (i == 0 || maximo < numero)
                {
                    maximo = numero;
                }

                acumulador += numero;
            }

            promedio = acumulador / 5;

            Console.WriteLine("Numero maximo: {0} \nNumero minimo: {1} \nPromedio: {2}", maximo, minimo, promedio);

            Console.ReadKey();
        }
    }
}
