﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    public class Validacion
    {                    
        public static bool Validar(string valor, int min, int max)
        {
            int number;
            if (int.TryParse(valor, out number) == true)
            {              
                if (number > min && number < max)
                {
                    return true;
                }                
            }
            return false;
        }
    }
}
