﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 0, min, max, acumulador = 0, promedio, minInput = 0, maxInput = 0;
            string strnumber;
            bool state;

            min = -100; max = 100;

            for (int i = 0; i < 10; i++)
            {
                do
                {
                    Console.WriteLine("Ingrese un numero en la posicion {0} de la lista", i + 1);
                    strnumber = Console.ReadLine();
                    if (Ejercicio_11.Validacion.Validar(strnumber, min, max) == false)
                    {
                        Console.WriteLine("numero invalido");
                        state = false;
                    }
                    else
                    {
                        number = Convert.ToInt32(strnumber);
                        state = true;
                        Console.WriteLine("numero correcto. {0}. Siguiente numero", number);
                        acumulador += number;
                        if (i == 0 || number > maxInput)
                        {
                            maxInput = number;
                        }
                        if (i == 0 || number < minInput)
                        {
                            minInput = number;
                        }
                    }

                } while (state == false) ;

            }
                    promedio = acumulador / 10;
                    Console.WriteLine("Promedio: {0}", promedio);
                    Console.WriteLine("Minimo: {0}", minInput);
                    Console.WriteLine("Maximo: {0}", maxInput);

                    Console.ReadKey();
         }

                
    }
 }

