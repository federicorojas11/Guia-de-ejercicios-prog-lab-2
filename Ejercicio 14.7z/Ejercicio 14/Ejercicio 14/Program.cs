﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            string strnumber,strnumber2;          
            double number, number2;

            Console.WriteLine("Ingrese numero para calcular area del cuadrado");
            strnumber = Console.ReadLine();
            number = Convert.ToDouble(strnumber);
            number = CalculoDelArea.Cuadrado(number);
            Console.WriteLine("Resultado: {0}", number);

            Console.WriteLine("Ingrese base y altura para calcular area del triangulo");
            strnumber = Console.ReadLine();
            number = Convert.ToDouble(strnumber);
            strnumber2 = Console.ReadLine();
            number2 = Convert.ToDouble(strnumber2);

            number = CalculoDelArea.Triangulo(number, number2);
            Console.WriteLine("Resultado: {0}", number);

            Console.WriteLine("Ingrese el radio para calcular area del circulo");
            strnumber = Console.ReadLine();
            number = Convert.ToDouble(strnumber);
            number = CalculoDelArea.Circulo(number);
            Console.WriteLine("Resultado: {0}", number);

            Console.ReadKey();
        }
    }
}
