﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    public class CalculoDelArea
    {

        public static double Cuadrado(double number)
            {
            double result;

            result = number * number; 

            return result;
            }

        public static double Triangulo(double baseNro, double alturaNro)
        {
            double result;

            result = baseNro * alturaNro;

            return result;
        }

        public static double Circulo(double radio)
        {
            double result;

            result = radio * radio * Math.PI;

            return result;
        }




    }
}
